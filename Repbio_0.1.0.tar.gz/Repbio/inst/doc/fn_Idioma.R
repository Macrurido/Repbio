## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_Idioma <- function(idioma,language){
    if(idioma==1){
        etiqueta<- unlist(language[[1]], use.names = FALSE)
    }else{
        etiqueta<- unlist(language[[2]], use.names = FALSE)
    } # End if
  etiqueta
} # End fn_Idioma

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
  # Labels are in English
  #   idioma <-   1
  #       fn_Idioma(idioma,language)
  # Labels are in Spanish
  #   idioma <-   2
  #       fn_Idioma(idioma,language)

