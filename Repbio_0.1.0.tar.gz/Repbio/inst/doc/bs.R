## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
bs <- function(df,B,n,semilla) {
  set.seed(semilla)
    mb <- matrix(sample(df, size = B * n,
                      replace = TRUE), B, n)
    mb <- rbind(df,mb)  # The resampling data is added with the original data
}     # End function bs

## ----warning=FALSE, message=FALSE---------------------------------------------
#       df = tmp
#       B <- 2000
#       n <- 3000
#       semilla <- 100
# # Reproducing the same output every time
#       ejemplo <- bs(df,B,n,semilla)
# 
# # Reproducing the different output every time
#       semilla <- NULL
#       ejemplo <- bs(df,B,n,semilla)

