## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_freq <- function(df, Imin, Imax, bin){
                  breaks<- seq(Imin, Imax, bin)
                  tmp.cut <- cut(df,breaks, right=FALSE)
                  fre = table(tmp.cut)
                  cum <- cumsum(fre)
                  frc <- cum/max(cum)
                  MCmin <- Imin+(bin/2)
                  MCmax <- Imax-(bin/2)
                  MC<- seq(MCmin,MCmax,bin)
                  cbind(MC,fre,cum,frc)
}   # End function

## ----warning=FALSE, message=FALSE---------------------------------------------
    # df <- tmp
    # Imin <- 1
    # Imax <- 30
    # bin <- 1
    # ejemplo <-  fn_freq(df, Imin, Imax, bin)

