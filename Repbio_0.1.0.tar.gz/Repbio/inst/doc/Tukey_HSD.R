## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
Tukey_HSD <- function(Prob, pval, HSD_main, HSD_trt, fn_hsd, etiquetas,
                      formula, criterio, Phases_legend){
  #  if (summary(Prob)[[1]][1, 5]<= 0.05){
  hsd_out <- agricolae::HSD.test(Prob, HSD_trt, group=TRUE,console=TRUE,
                      main=HSD_main, unbalanced = TRUE)
  sink(paste0("04_Tablas/Tukey_", as.character(formula)[2], "_",
              as.character(formula)[1],"_", criterio, ".txt"))
  print(hsd_out)
  sink()        # End sink

  # LTPh Contrast plot  ----
  r_names <- fn_hsd(hsd_out,Phases_legend) # Phase names are added.

  pdf(paste0("03_Figuras/Tukey_", as.character(formula)[2],"_",
             as.character(formula)[1],"_", criterio, ".pdf"))
  plot(hsd_out, xlab=etiquetas[6], ylab=etiquetas[5],xaxt = "n")
  par(usr=c(0.2,6.8,0.2,7))
  axis(1, labels = r_names, cex.axis=0.75,
       tick = FALSE, at=1:length(r_names))
  dev.off()
  #   } # End if
}  # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
   # pval <- 0.05
   # HSD_main <- LT/nPhase
   # HSD_trt <- Phase
   # exmple <- Tukey_HSD(Prob, pval, HSD_main, HSD_trt, fn_hsd, etiquetas,
   #                      formula, criterio, Phases_legend)

