## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
IC_plot <- function(x,y,yc,MClw,MCup,CIl,CIh,xl,yl){
  # Prediction lines and confidence intervals are smoothed
  smooth_yc <-  smooth.spline(x, yc, spar=0.4)
  CIls <- smooth.spline(x, CIl, spar=0.4)
  CIhs <- smooth.spline(x, CIh, spar=0.4)
  CIl <- as.vector(CIls$yin)
  CIh <- as.vector(CIhs$yin)

     plot(x,y,
       xlab= xl,
       ylab= yl,
       xlim= c(MClw,MCup),
       ylim= c(0,1),
       xaxt= "n",
       yaxt= "n",
       pch= 16, cex=0.8)
  lines(smooth_yc,col = "black", type = "l", lty = 1)

  polygon(c(x,rev(x)), c(CIl,rev(CIh)),
          col=rgb(0.5, 0.5, 0.5,0.2), border=NA)

 } # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
 #   IC_plot(x,y,yc,MClw,MCup,CIl,CIh,xl,yl)

