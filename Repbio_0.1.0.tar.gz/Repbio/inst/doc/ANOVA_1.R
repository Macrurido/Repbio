## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
ANOVA_1 <- function(formula,df,criterio){
            av1 <- aov(formula,df)
            anova1 <- anova(av1)

            sink(paste0("04_Tablas/ANOVA_",as.character(formula)[2],
                  as.character(formula)[3],"_",as.character(criterio),".txt"))
                  print(anova1)    # Guardo salida ANOVA en archivo txt
            sink()        # Cerrar sink
            av1
  } #End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
#formula <- LT~Phase
#criterio <- "AR"
#ejemplo <- ANOVA_1(formula,df,criterio)

