## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_porcentaje <- function(df, meses, immatures, Phases_legend) {
  # Total data number per column
  n_mes <- round(apply(X= df, MARGIN=2, FUN= sum),0)
  n_mes[n_mes == 0] <- "-"
  # Percentage calculation
  for (ii in 1:length(meses)) {
    if(sum(df[,ii]) == 0){
      df[ii] <-"-"
    }else{
      df[ii] <- round(100*df[,ii]/sum(df[,ii]),0)
    }  #end if
  } #end for

  # Add total data number per column
  countsp <- rbind (df,n_mes)
  names(countsp) <-meses
      if (immatures == 0){
          rownames(countsp) <- c(Phases_legend[-c(1)],"N")
      } else{
          rownames(countsp) <- c(Phases_legend,"N")
      } # end if
  countsp
} # end Function

## ----warning=FALSE, message=FALSE---------------------------------------------
    # df <- tmp
    # meses <- c("J","F","M","A","M","J","J","A","S","O","N","D")
    # immatures <- 0
    # Phases_legend <- c("II", "III", "IV", "V", "VI")
    # ejemplo <- fn_porcentaje(df, meses, immatures, Phases_legend)

