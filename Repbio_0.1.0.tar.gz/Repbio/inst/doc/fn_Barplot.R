## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_Barplot <- function(df,i,densidad,angulo){
  barplot(df[[i]],
          xlab="",
          xaxt = "n",
          legend = FALSE,
          density= densidad,
          angle=angulo,
          border="black",
          col="black"
  )
} # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
      # df <- tmp
      # i <- 2
      # densidad <- c(10,10,30,30,30,10)
      # angulo <- c(3,30,60,90,120,150)
      # 
      # fn_Barplot(df,i,density,angle)

