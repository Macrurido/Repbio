## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_LTGSI <- function(x, y, df, xl, yl, Icut, ylimit){
  plot(x , y,
       col = rgb(0,0,0,1/4),
       xlab= xl,
       ylab= yl,
       pch= c(0,1,15,16,17,2)[as.numeric(df$Phase)],
       ylim= ylimit,
       xaxt="n"
      )

      abline(h= Icut,col="black",lty = 2)
}  # End function fn_LTGSI

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
 #  x <-x
 #  y <- y
 #  df <- tmp
 #  xl <- etiquetas[1]
 #  yl <- etiquetas[3]
 #  Icut <- 2.3
 #  ylimit <- c(0,45)
 # ejemplo <- fn_LTGSI(x, y, df, xl, yl, Icut, ylimit)

