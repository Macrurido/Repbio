## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
modelo <- function(x,y,mod,bb,bmin,bmax){
  nlsLM(formula = mod,
        start = bb,
        lower = bmin,
        upper = bmax
  )
} # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
    # modelo(x,y,mod,bb,bmin,bmax)

