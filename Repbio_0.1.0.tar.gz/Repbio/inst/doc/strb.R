## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
strb <- function(b3,b4,b5,b6,b7,x,y,mod,modelo, bl, bu, xl, yl){
  bb <- c(b3=b3,b4=b4,b5=b5,b6=b6,b7=b7)
  bb <- bb[!is.na(bb)]
  bmin <- c(bb*bl)
  bmax <- c(bb*bu)
  fit <- modelo(x,y,mod,bb,bmin,bmax)

  plot(x,y,
       xlab=xl,
       ylab= yl)
  lines(x,fitted(fit))

  fit
} # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
    # strb(b3,b4,b5,b6,b7,x,y,mod,modelo, bl, bu, xl, yl)

