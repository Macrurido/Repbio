## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_coincide <- function(N_Phase, df, Icut, Coincide){
  df$PHIGS <- (ifelse(df$GSI >= Icut, 1, 0))
    for(i in 1:N_Phase+1){
    if(i < N_Phase+1){
      OK <- ifelse(df$Phase == i & df$MATURE == df$PHIGS, 1,0)
      MI <- ifelse(df$Phase == i & df$MATURE > df$PHIGS, 1,0)
      IM <- ifelse(df$Phase == i & df$MATURE < df$PHIGS, 1,0)
      Phase <- paste0("Phase_", as.roman(i))
    }else{
      OK <- ifelse(df$MATURE == df$PHIGS, 1,0)
      MI <- ifelse(df$MATURE > df$PHIGS, 1,0)
      IM <- ifelse(df$MATURE < df$PHIGS, 1,0)
      Phase <- "Total"
    } # End if
    Coincide [i,] <- c(Phase,sum(OK),sum(MI),sum(IM))
  } # End for
  Coincide
} # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
  # N_Phase <- 6
  # df <- tmp
  # Icut <- 2
  # Coincide <- data.frame(matrix(NA, ncol = 4, nrow = as.integer(N_Phase+1)))
  # 
  # ejemplo = fn_coincide(N_Phase, df, Icut, Coincide)

