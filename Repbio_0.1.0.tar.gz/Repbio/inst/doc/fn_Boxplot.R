## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Repbio)

## ----warning=FALSE, message=FALSE---------------------------------------------
fn_Boxplot <- function(val,fac,df,yrange){
  boxplot(val~fac,data=df,
          xlab="",
          ylab="",
          col="white",
          border="black",
          notch = FALSE,
          ylim= yrange,
          xaxt="n"
          )
} # End function

## ----warning=FALSE, message=FALSE, results='asis'-----------------------------
#   val <- tmp$LT
#   fac <- as.factor(tmp$Phase)
#   df <- tmp
#   yrange <- c(20,300)
#
#   ejemplo <- fn_Boxplot(val,fac,df,yrange)

